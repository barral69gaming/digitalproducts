HTML Micro‑Apps Pack
Five single-file apps (sample build).
License: MIT.
