AI Prompts Superpack Vol. 1
License: Single user. Use in commercial work allowed. Do not resell the CSV as-is.
